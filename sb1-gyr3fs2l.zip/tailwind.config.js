/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        inter: ['Inter', 'sans-serif'],
        manrope: ['Manrope', 'sans-serif'],
      },
      colors: {
        prism: {
          indigo: '#4F46E5',
          teal: '#14B8A6',
          charcoal: '#1F2937',
        },
        magnifi: {
          DEFAULT: '#4967D6',
          dark: '#4967D6',
        },
        sage: {
          DEFAULT: '#3F86C4',
          dark: '#3F86C4',
        },
        work: {
          DEFAULT: '#359AB8',
          dark: '#359AB8',
        },
        charcoal: {
          800: '#1F2937',
        },
      },
      backgroundImage: {
        'gradient-primary': 'linear-gradient(135deg, #4F46E5 0%, #14B8A6 100%)',
      },
      boxShadow: {
        'portfolio': '0 8px 24px -6px rgba(45, 52, 54, 0.12)',
        'portfolio-hover': '0 12px 48px rgba(45, 52, 54, 0.15)',
      },
    },
  },
  plugins: [],
};
import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import Slider from 'react-slick';
import PortfolioCard from '../components/PortfolioCard';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const portfolioItems = [
  {
    id: 1,
    title: 'Self AI',
    description: 'Building trusted AI Agents based on the users background, but with all the skills of Wall St',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" 
           stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" 
           className="h-7 w-7 text-white">
        <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/>
        <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/>
        <path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"/>
        <path d="M17.599 6.5a3 3 0 0 0 .399-1.375"/>
        <path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"/>
        <path d="M3.477 10.896a4 4 0 0 1 .585-.396"/>
        <path d="M19.938 10.5a4 4 0 0 1 .585.396"/>
        <path d="M6 18a4 4 0 0 1-1.967-.516"/>
        <path d="M19.967 17.484A4 4 0 0 1 18 18"/>
      </svg>
    ),
    bgColor: 'bg-magnifi',
    textColor: 'text-white',
    buttonColor: 'hover:bg-magnifi-dark',
    url: 'https://www.tryself.ai'
  },
  {
    id: 2,
    title: 'Orbit',
    description: 'Engineering the new middleware and middle office of Fintech with scalable AI Agent workforces.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" 
           stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" 
           className="h-7 w-7 text-white">
        <path d="M12.587 21.06l-1.25-1.25a14.902 14.902 0 0 1-6.231 2.307c-.712.094-1.4.18-2.15.043a.5.5 0 0 1-.437-.437c-.137-.75.05-1.438.144-2.15.24-1.803.913-3.513 2.307-6.23l-1.25-1.25a.978.978 0 0 1-.287-.688v-1.25c0-.362.294-.656.656-.656h1.25c.25 0 .488.125.63.325 1.812 2.625 4.45 4.025 7.207 4.025s5.395-1.4 7.207-4.025a.756.756 0 0 1 .63-.325h1.25c.362 0 .656.294.656.656v1.25c0 .25-.137.5-.344.625l-1.25.75a15.04 15.04 0 0 1-2.307 6.231c-.094.713-.18 1.4-.043 2.15a.5.5 0 0 1-.438.437c-.75.137-1.438-.05-2.15-.144-1.803-.24-3.513-.913-6.23-2.307l-1.25 1.25a.978.978 0 0 1-.688.287h-.012a.978.978 0 0 1-.688-.287zM12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/>
      </svg>
    ),
    bgColor: 'bg-sage',
    textColor: 'text-white',
    buttonColor: 'hover:bg-sage-dark',
    url: 'https://www.getorbit.io'
  },
  {
    id: 3,
    title: 'Coming Soon',
    description: 'Our 3rd portfolio company reimaging AI infrastructure.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" 
           stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" 
           className="h-7 w-7 text-white">
        <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>
        <path d="m9 12 2 2 4-4"/>
      </svg>
    ),
    bgColor: 'bg-work',
    textColor: 'text-white',
    buttonColor: 'hover:bg-work-dark'
  },
];

const HomePage = () => {
  const portfolioRef = useRef<HTMLDivElement>(null);
  const sliderRef = useRef<Slider>(null);
  const isPortfolioInView = useInView(portfolioRef, { once: true });

  const sliderSettings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    centerMode: false,
    accessibility: true,
    responsive: [
      {
        breakpoint: 1536,
        settings: {
          slidesToShow: 3,
          centerMode: false,
        }
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          centerMode: false,
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          centerMode: false,
        }
      }
    ]
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowLeft') {
      sliderRef.current?.slickPrev();
    } else if (e.key === 'ArrowRight') {
      sliderRef.current?.slickNext();
    }
  };

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ 
            backgroundImage: `url(https://dbawonxtljsjrsbrjruh.supabase.co/storage/v1/object/public/public-assets/PrismPartnerHeroImage.webp)`,
          }}
        >
          <div className="absolute inset-0 bg-black/50" />
        </div>
        <div className="absolute inset-0 bg-grid-pattern opacity-20" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center relative z-10"
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-inter font-bold text-white leading-tight mb-6">
              Illuminate Your
              <br />
              Financial Future
            </h1>
            <p className="text-xl lg:text-2xl text-gray-100 font-manrope max-w-3xl mx-auto mb-10">
              Harness the power of AI to optimize your investments and achieve your financial goals
              with confidence.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => portfolioRef.current?.scrollIntoView({ behavior: 'smooth' })}
                className="inline-flex items-center text-white font-inter hover:text-gray-200 transition-colors focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-prism-indigo rounded-lg"
              >
                Learn More
                <ChevronDown className="ml-2 h-5 w-5 animate-bounce" />
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Portfolio Carousel Section */}
      <section
        ref={portfolioRef}
        className="py-24 bg-gray-50 overflow-hidden"
        aria-label="Portfolio showcase"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isPortfolioInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-inter font-bold text-prism-charcoal mb-4">
              Our Portfolio
            </h2>
            <p className="text-xl text-gray-600 font-manrope max-w-2xl mx-auto">
              Discover how we're shaping the future of finance through our innovative portfolio companies.
            </p>
          </motion.div>

          <div
            className="relative -mx-4 sm:-mx-6 lg:-mx-8"
            onKeyDown={handleKeyDown}
            role="region"
            aria-label="Portfolio carousel"
            tabIndex={0}
          >
            <Slider ref={sliderRef} {...sliderSettings} className="portfolio-slider">
              {portfolioItems.map((item) => (
                <div key={item.id} className="px-4">
                  <PortfolioCard {...item} />
                </div>
              ))}
            </Slider>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center"
          >
            <div>
              <p className="text-4xl font-inter font-bold text-prism-indigo mb-2">3</p>
              <p className="text-gray-600 font-manrope">Portfolio Companies</p>
            </div>
            <div>
              <p className="text-4xl font-inter font-bold text-prism-indigo mb-2">50+</p>
              <p className="text-gray-600 font-manrope">Pending Patents</p>
            </div>
            <div>
              <p className="text-4xl font-inter font-bold text-prism-indigo mb-2">20+</p>
              <p className="text-gray-600 font-manrope">AI Agents</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative bg-gradient-primary py-24">
        <div className="absolute inset-0 bg-grid-pattern opacity-10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl lg:text-4xl font-inter font-bold text-white mb-6">
              Ready to Transform Your Financial Future?
            </h2>
            <p className="text-xl text-gray-100 font-manrope mb-10 max-w-2xl mx-auto">
              Join thousands of investors who are already benefiting from our AI-powered insights
              and expert guidance.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
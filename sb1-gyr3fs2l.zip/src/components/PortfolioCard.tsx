import React, { useRef, useState } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

interface PortfolioCardProps {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  bgColor: string;
  textColor: string;
  buttonColor: string;
  url?: string;
}

const PortfolioCard: React.FC<PortfolioCardProps> = ({
  title,
  description,
  icon,
  bgColor,
  textColor,
  buttonColor,
  url,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [5, -5]));
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-5, 5]));

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    x.set((e.clientX - centerX) / (rect.width / 2));
    y.set((e.clientY - centerY) / (rect.height / 2));
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
    setIsHovered(false);
  };

  return (
    <motion.div
      ref={cardRef}
      className="h-full max-w-[320px] mx-auto lg:mx-0"
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      style={{ perspective: 1000 }}
    >
      <motion.div
        className={`${bgColor} rounded-xl p-8 h-full shadow-portfolio hover:shadow-portfolio-hover transition-all duration-300`}
        style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}
      >
        <motion.div 
          className="w-14 h-14 bg-black/20 rounded-lg flex items-center justify-center mb-6"
          animate={{ scale: isHovered ? 1.1 : 1, rotate: isHovered ? -2 : 0 }}
          transition={{ duration: 0.3 }}
        >
          {icon}
        </motion.div>

        <motion.div style={{ transform: 'translateZ(20px)' }}>
          <h3 className={`text-2xl font-inter font-bold ${textColor} mb-4`}>
            {title}
          </h3>
          <p className={`${textColor} font-manrope mb-6 opacity-80`}>
            {description}
          </p>
          {url ? (
            <motion.a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className={`group inline-flex items-center font-inter ${textColor} ${buttonColor} focus:outline-none focus:ring-2 focus:ring-offset-2 rounded-lg transition-colors duration-300`}
              whileHover={{ x: 5 }}
              aria-label={`Learn more about ${title}`}
            >
              Learn More
              <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
            </motion.a>
          ) : (
            <motion.button
              className={`group inline-flex items-center font-inter ${textColor} ${buttonColor} focus:outline-none focus:ring-2 focus:ring-offset-2 rounded-lg transition-colors duration-300`}
              whileHover={{ x: 5 }}
              aria-label={`Learn more about ${title}`}
            >
              Learn More
              <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
            </motion.button>
          )}
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

export default PortfolioCard;